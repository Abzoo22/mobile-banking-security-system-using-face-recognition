from observer.observer import Observer
class Logger(Observer):
    def update(self, subject, event, message):
        print(f"[{event}] {message}")
