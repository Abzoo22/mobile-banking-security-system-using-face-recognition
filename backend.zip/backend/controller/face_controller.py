from model.face_recognizer import FaceRecognizer
from model.encryption_manager import EncryptionManager
from model.db_singleton import EmbeddingDatabase
import numpy as np
from observer.subject import Subject

class FaceController(Subject):
    def __init__(self):
        super().__init__()
        self.recognizer = FaceRecognizer()
        self.db = EmbeddingDatabase()

    def register_user(self, username, role, password, images):
        embeddings = []
        for image in images:
            face_coords = self.recognizer.detect_face(image)
            if face_coords is None:
                continue
            embedding = self.recognizer.get_embedding(image, face_coords)
            embeddings.append(embedding)
        
        if not embeddings:
            raise ValueError("No faces detected in any image")
        
        avg_embedding = np.mean(embeddings, axis=0)
        encrypted_embedding = EncryptionManager.encrypt_embedding(avg_embedding)
        encrypted_password = EncryptionManager.encrypt_text(password)
        self.db.save_user(username, role, encrypted_password, encrypted_embedding)
        self.notify("REGISTER", f"User {username} registered successfully.")

    def authenticate_user(self, image):
        face_coords = self.recognizer.detect_face(image)
        if face_coords is None:
            print(" No face detected in image.")
            return None, None, None
        
        embedding = self.recognizer.get_embedding(image, face_coords)
        user_row = self.db.verify_user(embedding)
        self.notify("LOGIN", f"User authenticated: {user_row}")
        
        if user_row is not None:
            return user_row['username'], user_row['role'], user_row['password']
        return None, None, None