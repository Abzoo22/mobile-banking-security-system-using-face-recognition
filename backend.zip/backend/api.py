from flask import Flask, request, jsonify
from controller.face_controller import FaceController
from model.encryption_manager import EncryptionManager
from observer.logger import Logger
import numpy as np
import base64
import cv2

app = Flask(__name__)
face_controller = FaceController()
logger = Logger()
face_controller.attach(logger)

@app.route("/register", methods=["POST"])
def register_user():
    try:
        data = request.get_json()
        name = data['name']
        role = data.get('role', 'user')  
        password = data['password']
        images_base64 = data['images']  

        images = []
        for img_str in images_base64:
            image_bytes = base64.b64decode(img_str)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            images.append(image)

        face_controller.register_user(name, role, password, images)

        return jsonify({'status': 'success', 'message': 'User registered successfully'}), 200

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@app.route("/authenticate", methods=["POST"])
def authenticate():
    data = request.json
    image_data = base64.b64decode(data['image'])
    password_input = data['password']

    npimg = np.frombuffer(image_data, np.uint8)
    img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)

    username, role, encrypted_password = face_controller.authenticate_user(img)
    if username is None:
        return jsonify({"status": "error", "message": "Face not recognized"}), 401

    try:
        decrypted_password = EncryptionManager.decrypt_text(encrypted_password)
    except Exception as e:
        return jsonify({"status": "error", "message": "Password decryption failed"}), 500

    if decrypted_password != password_input:
        return jsonify({"status": "error", "message": "Incorrect password"}), 401

    return jsonify({
        "status": "success",
        "username": username,
        "role": role
    })

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
