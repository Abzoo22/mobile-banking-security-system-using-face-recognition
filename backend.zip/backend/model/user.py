class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email

    def get_role(self):
        raise NotImplementedError("Subclasses must implement this method.")

    def has_permission(self, action):
        raise NotImplementedError("Subclasses must implement this method.")
