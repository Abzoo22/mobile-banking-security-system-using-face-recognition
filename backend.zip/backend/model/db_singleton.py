import pandas as pd
import numpy as np
from model.encryption_manager import EncryptionManager
FACE_THRESHOLD = 0.7  

class EmbeddingDatabase:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            if pd.io.common.file_exists("embeddings.csv"):
                cls._instance.data = pd.read_csv("embeddings.csv")
            else:
                cls._instance.data = pd.DataFrame(columns=["username", "role", "password", "embedding"])
        return cls._instance

    def save_user(self, username, role, password, encrypted_embedding):
        new_row = {"username": username, "role": role, "password": password, "embedding": encrypted_embedding}
        self.data = pd.concat([self.data, pd.DataFrame([new_row])], ignore_index=True)
        self.data.to_csv("embeddings.csv", index=False)

    def verify_user(self, embedding):
        best_match = None
        best_similarity = 0
        
        for _, row in self.data.iterrows():
            stored_embedding = EncryptionManager.decrypt_embedding(row["embedding"])
            
            dot_product = np.dot(stored_embedding, embedding)
            norm_stored = np.linalg.norm(stored_embedding)
            norm_input = np.linalg.norm(embedding)
            similarity = dot_product / (norm_stored * norm_input)
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_match = row
        
        return best_match if best_similarity > FACE_THRESHOLD else None