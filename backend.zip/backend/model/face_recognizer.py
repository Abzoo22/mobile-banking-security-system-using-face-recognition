import cv2
import numpy as np
from keras_facenet import FaceNet

class FaceRecognizer:
    def __init__(self):
        self.embedder = FaceNet()
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    def detect_face(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        return faces[0] if len(faces) > 0 else None

    def get_embedding(self, image, face_coords):
        x, y, w, h = face_coords
        face = image[y:y+h, x:x+w]
        face = cv2.resize(face, (160, 160))
        face_rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        return self.embedder.embeddings(np.expand_dims(face_rgb, axis=0))[0]