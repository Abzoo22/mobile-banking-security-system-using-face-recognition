import base64
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding as sym_padding
from cryptography.hazmat.backends import default_backend
ENCRYPTION_KEY = b'0123456789abcdef0123456789abcdef'
ENCRYPTION_IV = b'abcdef9876543210'

class EncryptionManager:
    @classmethod
    def encrypt_embedding(cls, embedding):
        embedding_bytes = embedding.astype(np.float32).tobytes()
        padder = sym_padding.PKCS7(128).padder()
        padded_data = padder.update(embedding_bytes) + padder.finalize()
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(ENCRYPTION_IV), backend=default_backend())
        ct = cipher.encryptor().update(padded_data) + cipher.encryptor().finalize()
        return base64.b64encode(ENCRYPTION_IV + ct).decode('utf-8')

    @classmethod
    def decrypt_embedding(cls, enc_str):
        raw = base64.b64decode(enc_str)
        iv = raw[:16]
        ct = raw[16:]
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        padded_data = cipher.decryptor().update(ct) + cipher.decryptor().finalize()
        unpadder = sym_padding.PKCS7(128).unpadder()
        data = unpadder.update(padded_data) + unpadder.finalize()
        return np.frombuffer(data, dtype=np.float32)

    @classmethod
    def encrypt_text(cls, text):
        padder = sym_padding.PKCS7(128).padder()
        padded = padder.update(text.encode()) + padder.finalize()
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(ENCRYPTION_IV), backend=default_backend())
        ct = cipher.encryptor().update(padded) + cipher.encryptor().finalize()
        return base64.b64encode(ENCRYPTION_IV + ct).decode('utf-8')

    @classmethod
    def decrypt_text(cls, enc_text):
        raw = base64.b64decode(enc_text)
        iv = raw[:16]
        ct = raw[16:]
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        padded = cipher.decryptor().update(ct) + cipher.decryptor().finalize()
        unpadder = sym_padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode()
