import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final  _picker = ImagePicker();

  List<File> _capturedImages = [];
  bool isLoading = false;
  String _message = "";

  Future<void> _captureImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _capturedImages.add(File(pickedFile.path));
      });
    }
  }

  Future<void> _registerUser() async {
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty || _capturedImages.length < 3) {
      setState(() {
        _message = "Please fill all fields and capture at least 3 images.";
      });
      return;
    }

    setState(() => isLoading = true);

    try { 
      List<String> base64Images = [];
      for (File imageFile in _capturedImages) {
        final imageBytes = await imageFile.readAsBytes();
        base64Images.add(base64Encode(imageBytes));
      }

      final response = await http.post(
        Uri.parse("http://192.168.1.15:5000/register"), 
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name": _usernameController.text,
          "password": _passwordController.text,
          "images": base64Images,
        }),
      );

      setState(() {
        isLoading = false;
        _message = response.statusCode == 200
            ? "Registration successful!"
            : "Registration failed: ${response.body}";
      });
    } catch (e) {
      setState(() {
        isLoading = false;
        _message = "Error: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Face Registration")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView(
          children: [
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(labelText: "Username"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: "Password"),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: isLoading ? null : _captureImage,
              child: const Text("Capture Face Image"),
            ),
            const SizedBox(height: 10),
            Text("Images Captured: ${_capturedImages.length}"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: isLoading ? null : _registerUser,
              child: isLoading
                  ? const CircularProgressIndicator()
                  : const Text("Register"),
            ),
            const SizedBox(height: 20),
            Text(_message),
          ],
        ),
      ),
    );
  }
}
