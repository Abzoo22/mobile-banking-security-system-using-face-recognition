import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:my_app/register.dart';
import 'home.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController password = TextEditingController();
  final TextEditingController username = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  bool isLoading = false;

Future<void> faceLogin() async {
  try {
    setState(() => isLoading = true);
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile == null) return;

    final imageBytes = await File(pickedFile.path).readAsBytes();
    final base64Image = base64Encode(imageBytes);

    final response = await http.post(
      Uri.parse("http://192.168.1.15:5000/authenticate"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"image": base64Image,"password": password.text.trim(),}),
    );

    final result = jsonDecode(response.body);
    if (result['status'] == 'success') {
      String username = result['username'] ?? "Unknown";
      String role = result['role'] ?? "user";

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(username: username, role: role),
        ),
      );
    } else {
      _showError(result['message'] ?? "Face login failed.");
    }
  } catch (e) {
    _showError("Face login error: $e");
  } finally {
    if (mounted) setState(() => isLoading = false);
  }
}

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 50),
                Image.asset('lib/images/img.jpg', height: 200),
                const SizedBox(height: 50),
                Text(
                  'Welcome to Best Bank',
                  style: TextStyle(color: Colors.grey[700], fontSize: 20),
                ),
                const SizedBox(height: 40),
Padding(
  padding: const EdgeInsets.symmetric(horizontal: 25.0),
  child: TextField(
    controller: username,
    decoration: InputDecoration(
      labelText: 'Username',
      border: OutlineInputBorder(),
    ),
  ),
),
const SizedBox(height: 20),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 25.0),
  child: TextField(
    controller: password,
    obscureText: true,
    decoration: InputDecoration(
      labelText: 'Password',
      border: OutlineInputBorder(),
    ),
  ),
),
const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: faceLogin,
                  label: const Text("Login with Face"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                const SizedBox(height: 20),

const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Row(
                    children: [
                      Expanded(child: Divider(thickness: 1, color: Colors.grey[400])),
                      Padding(
                        padding: const EdgeInsets.symmetric(),
                      ),
                      Expanded(child: Divider(thickness: 1, color: Colors.grey[400])),
                    ],
                  ),
                ),
                const SizedBox(height: 50),

                Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    const Text('Not a member?'),
    const SizedBox(width: 5),
    GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const RegisterPage()),
        );
      },
      child: const Text(
        'Register now',
        style: TextStyle(
          color: Colors.blue,
          fontWeight: FontWeight.bold,
          decoration: TextDecoration.underline,
        ),
      ),
    ),
  ],
),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
