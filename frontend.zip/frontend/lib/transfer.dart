import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class TransferPage extends StatefulWidget {
  final String username;
  final String role;

  const TransferPage({
    super.key,
    required this.username,
    required this.role,
  });

  @override
  State<TransferPage> createState() => _TransferPageState();
}

class _TransferPageState extends State<TransferPage> {
  final ImagePicker _picker = ImagePicker();
  bool isLoading = false;

  final TextEditingController recipientController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  Future<void> confirmWithFace() async {
    try {
      setState(() => isLoading = true);
      final pickedFile = await _picker.pickImage(source: ImageSource.camera);
      if (pickedFile == null) return;

      final imageBytes = await File(pickedFile.path).readAsBytes();
      final base64Image = base64Encode(imageBytes);

      final response = await http.post(
        Uri.parse("http://192.168.1.15:5000/authenticate"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"image": base64Image}),
      );

      final result = jsonDecode(response.body);
      if (result['status'] == 'success' &&
          result['username'] == widget.username) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Transfer confirmed and sent!')),
        );
      } else {
        _showError("Face verification failed. Transfer cancelled.");
      }
    } catch (e) {
      _showError("Error during face verification: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Transfer Money', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Your balance', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.grey[800])),
              const SizedBox(height: 4),
              Text('4,983 USD', style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 2, 141, 14))),
              const SizedBox(height: 32),

              Text('Recipient', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.grey[700])),
              const SizedBox(height: 8),
              TextField(
                controller: recipientController,
                decoration: InputDecoration(
                  hintText: 'Account Number',
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16.0), borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
                ),
              ),
              const SizedBox(height: 24),

              Text('Amount', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.grey[700])),
              const SizedBox(height: 8),
              TextField(
                controller: amountController,
                decoration: InputDecoration(
                  hintText: 'Enter amount to transfer',
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16.0), borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 48),

              isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (recipientController.text.isEmpty || amountController.text.isEmpty) {
                            _showError("Please enter all fields");
                          } else {
                            confirmWithFace();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple[600],
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          elevation: 5,
                        ),
                        child: const Text(
                          'Send Money',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
