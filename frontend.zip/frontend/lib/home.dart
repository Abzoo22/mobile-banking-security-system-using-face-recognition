import 'package:flutter/material.dart';
import 'transfer.dart';

class HomePage extends StatelessWidget {
  final String username;
  final String role;

  const HomePage({super.key, required this.username, required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 24.0, right: 24.0, bottom: 24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'You have',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.grey[800]),
                ),
                const SizedBox(height: 4),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: const [
                    Text(
                      '4,983 USD',
                      style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 2, 141, 14)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),

          
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: ElevatedButton.icon(
                      onPressed: () {

                      },
                      icon: const Icon(Icons.add),
                      label: const Text('ADD FUNDS'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TransferPage(
                            username: username,
                            role: role,
                            ),
                            ),
                          );
                        },
                      icon: const Icon(Icons.swap_horiz),
                      label: const Text('TRANSFER'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          
          Expanded(
            child: Container(
              color: Colors.grey[100],
              padding: const EdgeInsets.only(top: 24.0, left: 24.0, right: 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Activity',
                    style: TextStyle(fontSize: 40, fontWeight: FontWeight.w600, color: Colors.grey[800]),
                  ),
                  const SizedBox(height: 50),
                  Text(
                    'Uber                                         -30USD',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red[400]),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Startbucks                              -20USD',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red[400]),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
